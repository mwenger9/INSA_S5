/*
 * Ent�te correspondant aux m�thodes de tri
 *
 * Auteur: Ivan Leplumey
 * Date  : 20.10.2008
 *
 */

#ifndef TRI_H
#define TRI_H

#include "tableau.h"

void triNaif(Tableau *pt);

#endif
