import re
# Fonction de recherche des sabotiers
def listePatronymes(nom, dct):
    f = open(nom,'r')
    etat=0
    reg1=re.compile(r"\bINDI\b") 
    # …
    for ligne in f:
        if (etat==0):     # Etat initial
            res=reg1.search(ligne)
            if res!=None: # Etat individu détecté
                etat=1
        elif (etat==1):
            pass
        elif (etat==2):
            pass
        elif (etat==3):
                res=reg1.search(ligne)
                if res!=None: # Etat individu détecté
                    etat=1
    f.close()
# Affichage d’un dictionnaire
def affichageDict(dct):
    for c in dct.keys():
        print(c," : ",dct[c])

# Programme principal
if __name__ == "__main__":
    dct={}
    listePatronymes("resultat.txt",dct)
    affichageDict(dct)
