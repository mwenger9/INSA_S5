package main;
public interface Liste {
    public Iterateur iterateur();
    public boolean estVide();
    public void vider();
}
