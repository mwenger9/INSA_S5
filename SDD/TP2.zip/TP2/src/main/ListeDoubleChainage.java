package main;
public class ListeDoubleChainage implements Liste{

    private Maillon tete,queue,ec;

    public static class Maillon{
        Object val;
        Maillon pred;
        Maillon succ;
    }

    public ListeDoubleChainage(){
        Maillon tete = new Maillon();
        Maillon queue = new Maillon();

        tete.succ = queue;
        tete.pred = null;

        queue.succ = null;
        queue.pred = tete;

        this.tete = tete;
        this.ec = tete;
        this.queue = queue;
    }

    public boolean estVide(){
        return this.tete.succ == this.queue;
    }

    public void entete(){
        if(this.estVide()){
            this.ec = tete;
        }
        else {
            this.ec = tete.succ;
        }
    }

    public void enqueue(){
        if(this.estVide()){
            this.ec = queue;
        }
        else {
            this.ec = queue.pred;
        }
    }
    public void succ() throws IndexOutOfBoundsException{
        if(estSorti() || ec.succ == queue) {
            throw new IndexOutOfBoundsException("EC est hors de la liste ou veut en sortir");
        }
        this.ec = ec.succ;
    }
    public void pred() throws IndexOutOfBoundsException{
        if(estSorti() || ec.pred == tete) {
            throw new IndexOutOfBoundsException("EC est hors de la liste ou veut en sortir");
        }
        this.ec = ec.pred;
    }
    public void ajouterD(Object o){
        Maillon nouvMaillon = new Maillon();
        nouvMaillon.val = o;
        nouvMaillon.succ = ec.succ;
        nouvMaillon.pred = ec;
        ec.succ.pred = nouvMaillon;
        ec.succ = nouvMaillon;

        if(ec == tete){
            this.entete();
        } else this.succ();
    }
    public void oterec(){
        if(!estSorti()){
            ec.succ.pred = ec.pred;
            ec.pred.succ = ec.succ;
            ec = ec.succ;
        }
    }
    public Object valec() throws IndexOutOfBoundsException{
        if(this.estSorti()){
            throw new IndexOutOfBoundsException("EC est hors de la liste");
        }
        return this.ec.val;
    }
    public boolean estSorti(){
        return (ec == tete || ec == queue);
    }



}
