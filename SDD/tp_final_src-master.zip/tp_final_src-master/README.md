# TP files de priorité

L'énoncé à jour est sur Moodle https://moodleng.insa-rennes.fr/course/view.php?id=1034
