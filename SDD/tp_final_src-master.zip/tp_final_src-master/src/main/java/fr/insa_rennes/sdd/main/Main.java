package fr.insa_rennes.sdd.main;

public class Main {
	public static void main(String[] args) {
		
	}
}
